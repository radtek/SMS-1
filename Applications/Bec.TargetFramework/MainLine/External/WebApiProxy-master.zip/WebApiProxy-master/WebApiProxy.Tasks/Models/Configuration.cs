﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using WebApiProxy.Core.Models;

namespace WebApiProxy.Tasks.Models
{
    [XmlRoot("proxy")]
    public class Configuration
    {
        public const string ConfigFileName = "WebApiProxy.config";
        public const string CacheFile = "WebApiProxy.generated.cache";

        private string _clientSuffix = "Client";
        private string _name = "MyWebApiProxy";
        private bool _generateOnBuild = false;
        private string _namespace = "WebApi.Proxies";
        private string _enumsNamespace = "";
        private string _entitiesNamespace = "";

        [XmlAttribute("generateOnBuild")]
        public bool GenerateOnBuild
        {
            get
            {
                return this._generateOnBuild;
            }
            set
            {
                this._generateOnBuild = value;
            }
        }

        [XmlAttribute("clientSuffix")]
        public string ClientSuffix
        {
            get
            {
                return _clientSuffix.DefaultIfEmpty("Client");
            }
            set
            {
                _clientSuffix = value;
            }
        }

        [XmlAttribute("entitiesNamespace")]
        public string EntitiesNamespace
        {
            get
            {
                return this._entitiesNamespace;
            }
            set
            {
                this._entitiesNamespace = value;
            }
        }

        [XmlAttribute("enumsNamespace")]
        public string EnumsNamespace
        {
            get
            {
                return this._enumsNamespace;
            }
            set
            {
                this._enumsNamespace = value;
            }
        }

        [XmlAttribute("namespace")]
        public string Namespace
        {
            get
            {
                return this._namespace;
            }
            set
            {
                this._namespace = value;
            }
        }

        [XmlAttribute("name")]
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        [XmlAttribute("endpoint")]
        public string Endpoint { get; set; }

        [XmlIgnore]
        public Metadata Metadata { get; set; }

        public static Configuration Load(string root)
        {
            var fileName = root + Configuration.ConfigFileName;

            if (!File.Exists(fileName))
                throw new ConfigFileNotFoundException(fileName);

            var xml = File.ReadAllText(fileName);
            var serializer = new XmlSerializer(typeof(Configuration), new XmlRootAttribute("proxy"));
            var reader = new StreamReader(fileName);
            var config = (Configuration)serializer.Deserialize(reader);
            reader.Close();
            return config;

        }

    }

}