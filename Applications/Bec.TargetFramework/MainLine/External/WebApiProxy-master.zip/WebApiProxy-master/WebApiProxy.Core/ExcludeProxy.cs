﻿using System;

namespace WebApiProxy
{
    public class ExcludeProxy : Attribute
    {
    }
}
